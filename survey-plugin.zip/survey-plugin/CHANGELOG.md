#Changelog

## v1.0.20 - 2025-09-04
- added yes/no option
- updated urls referrencing this project
- added better structure for dev and prod

## v1.0.19 - 2025-09-1
- survey name is changed per page automatically
- dropdown now has options with comma-seperation

## v1.0.10 - 2025-05-20
- added ability to create custom surveys for different pages via shortcodes

## v1.0.8 - 2025-05-20
- adding ability to have multiple survey versions per page
- added style for survey dropdown

## v1.0.6 - 2025-05-20
- added dropdown option

## v1.0.4 - 2025-05-14
- changelog test to make sure
- that it works!

## v1.0.3 - 2025-05-14
- Testing change log

## v1.0.2 - 2025-05-14
- added auto updating

## v1.0.1 - 2025-05-14
- initial release