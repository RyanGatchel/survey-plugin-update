#Changelog

## v1.0.4 - 2025-05-14
- changelog test to make sure
- that it works!

## v1.0.3 - 2025-05-14
- Testing change log

## v1.0.2 - 2025-05-14
- got CI/CD working

## v1.0.1 - 2025-05-14
- initial release