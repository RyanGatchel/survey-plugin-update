<?php
/**
 * Plugin Name: Survey Plugin
 * Description: A chatbot-style survey plugin with ASU styling, admin-managed questions, DB storage, and CSV export.
 * Version: 1.0.3
 * Author: Ryan Gatchel
 * Update URL: https://ryangatchel.github.io/survey-plugin-update/update.json
 * Author URI: https://ryangatchel.io
 * Plugin URI: https://ryangatchel.io/survey-plugin
 */

if (!defined('ABSPATH')) exit;

register_activation_hook(__FILE__, 'asu_survey_create_table');
function asu_survey_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'asu_survey_responses';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        submission_time datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        responses longtext NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

add_action('admin_menu', function() {
    add_menu_page('ASU Survey', 'ASU Survey', 'manage_options', 'asu_survey', 'asu_survey_admin_page');
});

function asu_survey_admin_page() {
    echo '<div class="wrap"><h1>ASU Survey Questions</h1>';

    if (isset($_POST['asu_questions'])) {
        $sanitized_questions = [];
        foreach ($_POST['asu_questions'] as $q) {
            $sanitized_questions[] = [
                'text' => sanitize_text_field($q['text'] ?? ''),
                'yesno' => !empty($q['yesno'])
            ];
        }
        update_option('asu_survey_questions', $sanitized_questions);
        echo '<div class="updated"><p>Questions updated.</p></div>';
    }

    $questions = get_option('asu_survey_questions', []);
    echo '<form method="post"><table class="form-table">';
    for ($i = 0; $i < 10; $i++) {
        $text = isset($questions[$i]['text']) ? $questions[$i]['text'] : '';
        $yesno = !empty($questions[$i]['yesno']) ? 'checked' : '';
        echo '<tr>
            <th>Question ' . ($i + 1) . '</th>
            <td>
                <input type="text" name="asu_questions[' . $i . '][text]" value="' . esc_attr($text) . '" size="60">
                <label><input type="checkbox" name="asu_questions[' . $i . '][yesno]" value="1" ' . $yesno . '> Yes/No</label>
            </td>
        </tr>';
    }
    echo '</table><p><input type="submit" class="button-primary" value="Save Questions"></p></form>';

    echo '<h2>Export Responses</h2><p><a class="button" href="' . admin_url('admin-ajax.php?action=asu_export_csv') . '">Download CSV</a></p>';
    echo '</div>';
}

add_action('wp_ajax_asu_export_csv', function() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'asu_survey_responses';
    $results = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename=asu_survey_responses.csv');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Submission Time', 'Responses']);
    foreach ($results as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
});

add_shortcode('asu_survey_form', function() {
    $questions = get_option('asu_survey_questions', []);
    $filtered_questions = array_values(array_filter($questions, function($q) {
        return !empty($q['text']);
    }));

    wp_enqueue_script('asu-chatbot-js', plugins_url('main.js', __FILE__), ['jquery'], null, true);
    wp_localize_script('asu-chatbot-js', 'asuSurveyData', [
        'questions' => $filtered_questions,
        'ajaxUrl' => admin_url('admin-ajax.php')
    ]);

    wp_enqueue_style('asu-chatbot-style', plugins_url('style.css', __FILE__));

    return '<div class="asu-chatbot-launcher">
        <img src="' . plugins_url('chat_icon.png', __FILE__) . '" id="asu-toggle-chat" alt="Chatbot Icon" />
        <div id="asu-chatbot-wrapper" class="asu-chatbot-wrapper" style="display:none;">
            <div class="asu-chatbot-header">Health Observatory</div>
            <div id="asu-chat-container" class="asu-chat-container"></div>
            <button id="asu-start-chat" class="asu-start-button">Start Survey</button>
            <div class="asu-chatbot-footer">
                Built by <a href="https://ryangatchel.io" target="_blank">Ryan Gatchel</a>
            </div>
        </div>
    </div>';
});

add_action('wp_ajax_asu_submit_survey', 'asu_submit_survey');
add_action('wp_ajax_nopriv_asu_submit_survey', 'asu_submit_survey');

function asu_submit_survey() {
    global $wpdb;
    $table = $wpdb->prefix . 'asu_survey_responses';
    $data = json_decode(stripslashes($_POST['responses']), true);
    $wpdb->insert($table, ['responses' => json_encode($data)]);
    wp_send_json_success();
}
require_once plugin_dir_path(__FILE__) . 'diagnostic-page.php';
require_once plugin_dir_path(__FILE__) . 'update-check.php';