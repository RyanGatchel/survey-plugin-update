# Survey Plugin Usage

The Survey Plugin is a custom WordPress plugin designed to let site administrators create and manage surveys. It supports collecting survey responses, storing them in the database, exporting to a CSV file.

## System Architecture

### components

- Frontend Survey Form: Rendered via a shortcode `[survey_form]` or `[survey_form set=second_form]` that outputs a form based on the survey configured in the admin dashboard.
- Admin Interface: Allows users to manage survey questions, answer types (e.g., text, dropdown, yes & no), and export responses.
- Database: custom table is created.

## Requirements

- WordPress 5.8+
- PHP 7.4+
- MySQL 5.7+

## Installation

>[!NOTE]
>This will be updated to add a better way to download.

1. Login to your dashboard
2. Activate the plugin through the 'Plugins' menu in WordPress.

## Usage

After activation, navigate to the Survey section in your WordPress admin dashboard to create and manage surveys.

## Features

- Dynamic Survey Form | Using shortcodes to show the forms
- Dashboard Editor | Allows users to create their own surveys 
- Export Responses | Download responses as CSV

## Future Enhancements

- [ ] Email Service Integrations
- [ ] Graphical dashboard for response analaytics data
- [ ] Custom naming for survey 

# Survey Plugin Development

If you want to make your own version or add features to this one. This is the information that you need.

## File Structure

/survey-plugin/

|- survey-plugin.php</br>
|- style.css</br>
|- main.js</br>
|- chat_icon.png</br> 
|- update-check.php `if you want updates automatically`

## License

GPLv2