# Survey Plugin Usage

The Survey Plugin is a custom WordPress plugin designed to let site administrators create and manage surveys. It supports collecting survey responses, storing them in the database, exporting to a CSV file.

## System Architecture

### components

- Frontend Survey Form: Rendered via a shortcode `[survey_form]` or `[survey_form set=your_form_name]` that outputs a form based on the survey configured in the admin dashboard.
- Admin Interface: Allows users to manage survey questions, answer types (e.g., text, dropdown, yes & no), and export responses.
- Database: custom table is created.

## Requirements

- WordPress 5.8+
- PHP 7.4+
- MySQL 5.7+

## Installation

>[!NOTE]
>This will be updated to add a better way to download.

1. Login to your dashboard
2. Activate the plugin through the 'Plugins' menu in WordPress.

## Usage

After activation, navigate to the Survey section in your WordPress admin dashboard to create and manage surveys.

## Features

- Dynamic Survey Form | Using shortcodes to show the forms
- Dashboard Editor | Allows users to create their own surveys
![The dashboard editor showing where you put your questions and create new question sets](https://ryangatchel.github.io/survey-plugin-update/survey_example.png)
- Export Responses | Download responses as CSV
![Option to export responses as a CSV file](https://ryangatchel.github.io/survey-plugin-update/export_responses.png)

## Shortcodes

- `[survey_form]`  **default shortcode** 
- `[survey_form set=your_form_name]` **custom form shortcode**

## Future Enhancements

- [ ] Email Service Integrations
- [ ] Graphical dashboard for response analaytics data
- [ ] Custom naming for survey 

# Survey Plugin Development

If you want to make your own version or add features to this one. This is the information that you need.

## Cloning Instructions

>[!NOTE]
>Make sure you clone from `dev`.

1. setup a folder on your computer `survey-project` or a different name.
2. run `git init` if Git isn't initiated.
2. clone this project in your folder using `git clone https://github.com/RyanGatchel/survey-plugin.git --branch dev`

## File Structure

/survey-plugin/

|- survey-plugin.php</br>
|- /release-assets</br>
|-- diagnostic-page.php</br>
|-- update-check.php</br>
|- /src</br>
|-- style.css</br>
|-- main.js</br>
|-- chat_icon.png</br> 


## Core Logic

1. User fills out and submits the survey form.
2. Javascript sends data via AJAX to WordPress backend.
3. Backend validates and sanitizes data.
4. Data is saved too `survey_responses` in database

## Testing

- Create a quick survey
- Create a test page and add shortcode
- Click `Start Survey`
- Open DevTools
- Fill-out your survey and look for admin-ajax.php in Network tab.
- If you see it then it's working currectly. 

## Troubleshooting

- Survey not showing | confirm shortcode is added
- CSV download fails | make sure you're an admin | check file permissions

## Contributors

- Lead Developer: [Ryan Gatchel](https://ryangatchel.io) - ryan@ryangatchel.io
- Github Repo: [Survey Plugin Repo](https://github.com/RyanGatchel/survey-plugin)
- Report Issues: [Report Issues](https://github.com/RyanGatchel/survey-plugin/issues)

## License

GPLv2