jQuery(document).ready(function ($) {
    const questions = asuSurveyData.questions;
    const chatBox = $('#asu-chat-container');
    let answers = [];
    let current = 0;

    function addMessage(text, sender = 'bot') {
        const bubble = $('<div class="chat-bubble ' + sender + '">').text(text);
        chatBox.append(bubble);
        chatBox.scrollTop(chatBox[0].scrollHeight);
    }

    function askQuestion() {
        if (current < questions.length) {
            const question = questions[current];
            setTimeout(() => {
                addMessage(question.text);
                renderInput(question.yesno);
            }, 500);
        } else {

            $.post(asuSurveyData.ajaxUrl, {
                action: 'asu_submit_survey',
                responses: JSON.stringify(answers)
            }, () => {
                addMessage('Thanks for your responses! 🎓');
            });
        }
    }

    function renderInput(isYesNo) {
        if (isYesNo) {
            const container = $('<div class="chat-options"></div>');
            const yesBtn = $('<button class="chat-option-btn">Yes</button>');
            const noBtn = $('<button class="chat-option-btn">No</button>');
            yesBtn.click(() => handleAnswer('Yes'));
            noBtn.click(() => handleAnswer('No'));
            container.append(yesBtn, noBtn);
            chatBox.append(container);
        } else {
            const input = $('<input type="text" class="chat-input" placeholder="Type your answer...">');
            chatBox.append(input);
            input.focus();
        }
        chatBox.scrollTop(chatBox[0].scrollHeight);
    }

    function handleAnswer(response) {
        $('.chat-input, .chat-options').remove();
        addMessage(response, 'user');
        answers.push({ [questions[current].text]: response });
        current++;
        askQuestion();
    }

    chatBox.on('keypress', '.chat-input', function (e) {
        if (e.which === 13) {
            const val = $(this).val();
            if (val.trim()) {
                handleAnswer(val.trim());
            }
        }
    });

    $('#asu-start-chat').click(function () {
        $(this).hide();
        askQuestion();
    });

    $('#asu-toggle-chat').click(() => {
        $('#asu-chatbot-wrapper').toggle();
    });
});
