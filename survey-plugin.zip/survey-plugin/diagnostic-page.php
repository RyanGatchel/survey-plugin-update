<?php

add_action('admin_menu', function() {
    add_submenu_page(
        'tools.php', // Or use 'options-general.php' or 'dashboard' if preferred
        'Survey Plugin Diagnostics',
        'Survey Diagnostics',
        'manage_options',
        'survey-plugin-diagnostics',
        'survey_plugin_diagnostics_page'
    );
});

function survey_plugin_diagnostics_page() {
    $plugin_file = 'survey-plugin/survey-plugin.php';
    $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file);
    $installed_version = $plugin_data['Version'];

    $remote_url = 'https://ryangatchel.github.io/survey-plugin-update/update.json';
    $remote_version = 'Unavailable';
    $update_available = 'Unknown';
    $error = null;

    $response = wp_remote_get($remote_url);
    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
        $data = json_decode(wp_remote_retrieve_body($response));
        $remote_version = $data->version ?? 'Not found';

        if (version_compare($remote_version, $installed_version, '>')) {
            $update_available = '✅ Yes';
        } else {
            $update_available = '❌ No';
        }
    } else {
        $error = is_wp_error($response) ? $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code($response);
    }

    echo '<div class="wrap"><h1>Survey Plugin Diagnostics</h1><table class="widefat fixed striped">';
    echo '<tr><th>Installed Version</th><td>' . esc_html($installed_version) . '</td></tr>';
    echo '<tr><th>Remote Version</th><td>' . esc_html($remote_version) . '</td></tr>';
    echo '<tr><th>Update Available</th><td>' . esc_html($update_available) . '</td></tr>';
    if ($error) {
        echo '<tr><th>Error</th><td style="color:red;">' . esc_html($error) . '</td></tr>';
    }
    echo '</table></div>';
}
