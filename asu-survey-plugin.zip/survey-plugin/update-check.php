<?php

add_filter('site_transient_update_plugins', 'asu_survey_plugin_check_for_update');

function asu_survey_plugin_check_for_update($transient) {
    if (empty($transient->checked)) {
        return $transient;
    }

    $plugin_slug = 'asu-survey-plugin/asu-survey-plugin.php';
    $remote_url = 'https://ryangatchel.github.io/survey-plugin-update/update.json';

    $response = wp_remote_get($remote_url);
    if (
        is_wp_error($response) || 
        wp_remote_retrieve_response_code($response) !== 200
    ) {
        return $transient;
    }

    $data = json_decode(wp_remote_retrieve_body($response));
    if (
        isset($data->version) && 
        version_compare($data->version, '1.0.0', '>')
    ) {
        $transient->response[$plugin_slug] = (object)[
            'slug' => $plugin_slug,
            'plugin' => $plugin_slug,
            'new_version' => $data->version,
            'package' => $data->download_url,
            'tested' => '6.5',
            'requires' => '5.0',
        ];
    }

    return $transient;
}
