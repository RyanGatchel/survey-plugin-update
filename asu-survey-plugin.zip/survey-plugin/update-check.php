<?php

add_filter('site_transient_update_plugins', 'asu_survey_plugin_check_for_update');

function asu_survey_plugin_check_for_update($transient) {
    if (empty($transient->checked)) {
        return $transient;
    }

    $plugin_slug = 'asu-survey-plugin/asu-survey-plugin.php';
    $remote_url = 'https://ryangatchel.github.io/survey-plugin-update/update.json';

    $response = wp_remote_get($remote_url);
    if (
        is_wp_error($response) || 
        wp_remote_retrieve_response_code($response) !== 200
    ) {
        return $transient;
    }

    $data = json_decode(wp_remote_retrieve_body($response));
    if (
        isset($data->version) &&
        isset($transient->checked[$plugin_slug]) &&
        version_compare($data->version, $transient->checked[$plugin_slug], '>')
    ) {
        $transient->response[$plugin_slug] = (object)[
            'slug' => 'asu-survey-plugin',
            'plugin' => $plugin_slug,
            'new_version' => $data->version,
            'package' => $data->download_url,
            'tested' => $data->tested ?? '',
            'requires' => $data->requires ?? '',
        ];
    }

    return $transient;
}

add_filter('plugins_api', 'asu_survey_plugin_plugin_api', 20, 3);

function asu_survey_plugin_plugin_api($result, $action, $args) {
    if ($action !== 'plugin_information' || $args->slug !== 'asu-survey-plugin') {
        return $result;
    }

    $remote_url = 'https://ryangatchel.github.io/survey-plugin-update/update.json';
    $response = wp_remote_get($remote_url);

    if (
        is_wp_error($response) || 
        wp_remote_retrieve_response_code($response) !== 200
    ) {
        return $result;
    }

    $data = json_decode(wp_remote_retrieve_body($response));

    return (object)[
        'name' => 'ASU Survey Plugin',
        'slug' => 'asu-survey-plugin',
        'version' => $data->version,
        'author' => $data->author,
        'author_profile' => $data->author_profile,
        'requires' => $data->requires,
        'tested' => $data->tested,
        'sections' => (array)$data->sections,
        'banners' => (array)$data->banners,
        'download_link' => $data->download_url,
    ];
}
